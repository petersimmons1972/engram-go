---
name: Session Handoff 2026-03-27 — Armies 2.0 Foundation
description: Full state of Armies 2.0 project after initial build session
type: project
---

# Session Handoff: Armies 2.0 Foundation

## What Was Done

- Created `~/projects/armies/` — full directory structure, git init, remote wired to `github.com/petersimmons1972/armies`
- Extracted all rules from generals into `/rules/*.yaml`: progression.yaml (515L), competence-categories.yaml (392L), malus-schema.yaml (549L), eligibility.yaml (306L), role-taxonomy.yaml, rank-schema.yaml
- Wrote `schema/profile-schema.yaml` — layered profile format (frontmatter + Base Persona + per-role blocks, progressive loading)
- 5 team templates in `teams/`: standard, quality-sprint, research-spike, firefighting, planning-session
- Python CLI at `src/armies/` — 6 commands: roster, spawn, eligible, sync, init, research. `armies research` generates a Claude Code agent prompt (NOT API call). `pyproject.toml` included.
- Docker packaging: `docker/Dockerfile`, `docker-compose.yaml`, `docker/README.md`, `.dockerignore`. `~/.armies/` is a volume mount — data survives container removal.
- 11 example profiles in `profiles/examples/` — all 8 role classes covered across two thematic sets:
  - Scientists: Lovelace (researcher), Hopper (implementer), Turing (qa-validator), Tesla (planner), Lamarr (troubleshooter)
  - Creatives: Roy Disney (coordinator), Walt Disney (artist, affinity: roy-disney), Geisel (planner+artist), Vannevar Bush (coordinator), Saul Bass (artist), Jane Goodall (observer)
- `profiles/examples/README.md` — methodology guide + full 8-role coverage table + PR invitation
- `CONTRIBUTING.md` — profile submission guide

## Next Steps

- ✅ All 11 example profiles committed and pushed — repo is complete
- Write `docs/` with narrative documentation — user wants richly illustrated, story-driven, NOT sparse command references (saved in global-todo-list.md)
- Create GitHub release with diagrams and proper README
- Port private generals profiles to `~/.armies/` format (user-driven, separate session)
- GitHub Actions for automated sync/backup (open question)

## Key Design Decisions Locked

- Role tags are **mission selectors** — one active per spawn, not identity locks
- Profiles are **layered**: Base Persona always loads + ONE role block per spawn
- Private IP (journalists, real generals profiles) lives in `~/.armies/` never in public repo
- `armies research` uses Claude Code Agent tool, NOT Anthropic API (`--mode api` is a future stub)
- Walt Disney requires Roy Disney as coordinator (`affinity` field, advisory not enforced)
- Public examples use non-military figures to show engine is persona-agnostic

## Open Questions for User

- Rehabilitation path for Eisenhower's permanent malus entries?
- Second example profile set theme: military figures, or another domain (film crew, kitchen brigade)?
- GitHub Actions for automated `~/.armies/` sync/backup?

## Files Changed

- `~/projects/armies/` — entire new repo (new)
- `~/.claude/projects/-home-psimmons/memory/global-todo-list.md` — armies doc standard added
