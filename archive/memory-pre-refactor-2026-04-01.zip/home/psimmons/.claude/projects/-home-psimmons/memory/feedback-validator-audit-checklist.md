---
name: Validator audit checklist — don't trust naming conventions
description: Exploration agents falsely flagged 4 "duplicate" validator pairs in Clearwatch that were actually distinct tools at distinct stages. Direct inspection is mandatory before any consolidation.
type: feedback
---

Never conclude two validators are duplicates based on naming convention or conceptual overlap alone. Validators with similar names (e.g., `ciso_validator.py` and `ciso_criteria_validator.py`) routinely serve different stages, callers, interfaces, and return types.

**Before any validator consolidation, verify all four:**
1. Same interface / return type?
2. Same caller in the pipeline?
3. Registered in the same stage?
4. Same violation/result format?

If any answer is NO — they are not duplicates.

**Why:** 2026-03-30, Clearwatch session — exploration agents flagged 4 "duplicate" pairs. All were false positives. If the consolidation had proceeded, it would have broken Stage 6 gates, `persona_review_integration.py`, and the learning/graduation system.

**How to apply:** Any time a "consolidation audit" is requested, do direct inspection of imports and callers — not pattern-matching on names — before writing a plan.

**Stage 6 corollary:** Gate 14 failure short-circuits gates 15–26. Stage 6 gates are NOT safely parallelizable. Parallelizing them would produce misleading results (later gates running on already-blocked content).
