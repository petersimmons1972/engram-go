---
name: Always file GitHub issues without asking
description: When new bugs or follow-up items are found during work, file them immediately — never ask permission first
type: feedback
---

Always file GitHub issues for any bugs, follow-up items, or defects found during work. Do not ask the user whether to file them. Just file them.

**Why:** "Always file new issues. Do not ask." — direct correction when I asked before filing #3842 and #3843.

**How to apply:** When work surfaces a new bug or a follow-up item that needs tracking, file the GitHub issue immediately as part of completing the work. Asking "should I file this?" wastes a round-trip. This aligns with CLAUDE.md "Bug & Defect Tracking — NON-NEGOTIABLE" section which already states issues must be filed before continuing.
