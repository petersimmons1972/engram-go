---
name: feedback-dont-modify-upstream-plugin-cache
description: Never edit files inside ~/.claude/plugins/cache/ — they belong to upstream and cause conflicts on upgrade
type: feedback
---

Never modify skill files inside `~/.claude/plugins/cache/`. Those files are owned by the upstream plugin author and will conflict on the next upgrade.

**Why:** Session 2026-03-31 — had local edits to 3 superpowers skill files (brainstorming, executing-plans, subagent-driven-development). Blocked the v4.0.3→v5.0.7 upgrade. All three changes were redundant — upstream had already added the same rules by v5.0.7.

**How to apply:**
- Policy rules → `~/CLAUDE.md` or project `CLAUDE.md`
- Custom skills → `~/.claude/skills/` (global) or `{project}/.claude/skills/` (project-scoped)
- Never touch `~/.claude/plugins/cache/**`
