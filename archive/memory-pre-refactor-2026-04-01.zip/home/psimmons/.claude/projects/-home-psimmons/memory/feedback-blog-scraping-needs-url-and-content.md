---
name: Blog scraping by anchor text alone is useless
description: Blog listing page scrapers must check URLs and fetch article content — anchor text on listing pages is too generic to match keywords
type: feedback
---

Scraping vendor blog listing pages by anchor text alone yields near-zero matches. Blog listing pages use generic anchors ("Read more", article headlines without event names). The RSAC collector scanned 4000+ anchors across 18 vendor blogs and matched zero.

**Why:** Vendor RSAC announcements are titled things like "Charlotte AI Enhancements" or "Falcon Next-Gen SIEM Updates" — not "CrowdStrike at RSAC 2026." The conference name appears inside the article body or in the URL path (`/blog/rsac-2026/`), not in the anchor text.

**How to apply:** Blog scrapers should: (1) check both anchor text AND href URL for keywords, (2) fetch the linked article's `<title>` tag and first ~2000 chars of body text, (3) match keywords against the full searchable text. Accept the additional HTTP requests as the cost of useful data.
