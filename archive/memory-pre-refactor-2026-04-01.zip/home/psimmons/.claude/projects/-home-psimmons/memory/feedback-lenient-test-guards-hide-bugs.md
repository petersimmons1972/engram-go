---
name: Lenient test guards hide bugs
description: Tests with if-guards that skip assertions when data is empty will silently pass when the data source is broken
type: feedback
---

Tests that use `if result: assert X in result` hide broken data sources. The detection_efficacy methodology anchors were broken for months because `build_methodology_anchors("detection_efficacy")` returned empty string, and the test had `if anchors: assert "MITRE" in anchors` — skipping the assertion entirely.

**Why:** A lenient guard was added because "domain-knowledge files might not exist" during testing. In practice, the files always exist — the bug was mismatched section markers (`"## MITRE Adversary..."` vs actual `"### Rule 3: Adversary..."`). The guard hid the real failure.

**How to apply:** When writing tests for data-loading functions, assert the data IS loaded (non-empty), not just that it's correct IF loaded. Use `assert len(result) > 0, "should load X"` as the first assertion. If the data source is genuinely optional, make that a separate test from the content validation test.
