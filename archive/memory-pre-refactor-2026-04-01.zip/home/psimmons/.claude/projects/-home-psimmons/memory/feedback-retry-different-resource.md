---
name: feedback-retry-different-resource
description: When retrying after a resource-contention failure, always select a DIFFERENT resource — retrying the same one repeats the failure
type: feedback
Category: feedback
---

When a resource fails due to contention (busy pod, locked process, concurrent access), the retry MUST target a different resource instance. Retrying the same one guarantees re-hitting the same contention.

**Why:** Clearwatch visual-tester k8s pod used PID-based selection (`os.getpid() % len(ready_pods)`). Under 3-way concurrency (3 report runs, 2 pods), the pigeonhole theorem guarantees collision — at least one pod gets 2 processes. The original retry code re-used the same `pod` variable, so the retry always hit the same busy Chromium instance. Fixed by passing `exclude=pod` to the pod selector on retry.

**The fix pattern:**
```python
# WRONG: retry on same resource
alt_pod = self._get_running_pod() or pod
result = self._exec(alt_pod, cmd)

# RIGHT: exclude the failing resource
alt_pod = self._get_running_pod(exclude=failing_pod) or failing_pod
result = self._exec(alt_pod, cmd)
```

**How to apply:**
- Any retry after a "resource busy / empty output / contention" error: explicitly exclude the failing resource
- Works for: k8s pods, database connections, worker threads, file locks
- If only one resource exists: still retry (may have transient state), but log a warning that no alternate was available
- The warning message about Chromium contention existed in the code for months — it took 3-way concurrency to surface it as a hard failure. Don't wait for it to blow up; fix contention retry logic when you first write it.
