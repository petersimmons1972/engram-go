---
name: feedback-precommit-hook-exit128
description: Exit 128 on git commit usually means the pre-commit hook ran the full test suite and the commit state was already resolved — not a test failure
type: feedback
---

In Clearwatch, the pre-commit hook runs the full pytest suite (~6900 tests) before every commit. When a merge conflict was resolved and the agent tried to commit, it got exit 128 twice. The tests were actually passing — the 128 was a git state issue (trying to commit when nothing was staged or merge was already complete).

**Why:** Session 2026-03-31 — RSAC merge conflict resolution triggered two failed commit attempts. The merge had already completed; the agent was trying to re-commit unnecessarily.

**How to apply:**
- Exit 128 from git commit = check `git status` first, not test output
- If tests show all dots/skips and then exit 128, the commit state is the problem, not the tests
- Always run `git log --oneline -3` to confirm whether the merge already landed before retrying
