---
name: Fix classes not instances — consolidate before implementing
description: When facing 15+ related issues, consolidate into 3-5 rule groups before writing any code — the grouping reveals the real architecture
type: feedback
---

35 prompt-quality issues looked like 35 separate fixes. Consolidating into 15 bug classes, then into 5 rule groups (Evidence Integrity, Human Voice, Balanced Scrutiny, Reader Accessibility, Pricing Precision) revealed that most issues shared root causes. The 5 groups needed ~607 words of prompt additions total — well within existing word budgets.

**Why:** Instance-level thinking produces 35 patches that conflict and bloat. Class-level thinking produces 5 principles that naturally cover edge cases. The consolidation step IS the design work — it forces you to find the unifying principle behind surface symptoms.

**How to apply:** When issue count exceeds 10, categorize first (buckets), then cluster into classes (shared root cause), then consolidate into rule groups (shared principle). Implementation targets the rule groups, not the individual issues. Each rule group gets one unifying principle stated in natural language, not a checklist.
