---
name: feedback-plugin-update-cli-worktree-bug
description: claude plugin update fails when run from a git worktree — update the cache directly via git instead
type: feedback
---

`claude plugin update <name>` fails with scope errors when run from a git worktree, even with `--scope project`. The CLI uses the cwd to find the project scope and gets confused by worktree paths.

**Why:** Session 2026-03-31 — `claude plugin update superpowers@superpowers-marketplace` failed from the clearwatch worktree. Manual git checkout of the version tag in the cache directory worked instead.

**How to apply:**
- To update a plugin manually: `cd ~/.claude/plugins/cache/{marketplace}/{plugin}/{version} && git fetch origin && git checkout v{version}`
- Also update `~/.claude/plugins/installed_plugins.json` with the new version, date, and git SHA
- Run `claude plugin update` only from the actual project root, never from a worktree
