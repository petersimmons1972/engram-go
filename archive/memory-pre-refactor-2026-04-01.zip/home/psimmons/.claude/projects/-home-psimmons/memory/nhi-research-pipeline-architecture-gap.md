---
name: nhi-research-pipeline-architecture-gap
description: NHI/SSPM research built outside framework, needs architectural redesign before cron-job band-aids
type: project
---

## NHI Research Pipeline Architecture Gap

**Filed as:** #3841

**Discovery Date:** 2026-03-31

**Status:** Deferred for Opus-level architectural review (next week)

### The Issue

NHI/SSPM research (Operation Triple Crown, commit d2acef5) was built outside the normal collector framework:
- 119 research files (Mar 13-20) live in `/research/cache/` as git-tracked staging
- Stage 3 pipeline reads from **database only**, not filesystem
- Files are invisible to report generation unless manually imported via `import_research_cache.py`
- No automation exists to move files from cache → database

### Why It Matters

The cache was designed as a temporary staging area (Feb 28 migration plan). Files shouldn't live there long-term. But the NHI work bypassed the normal `ResearchStore` → database flow entirely.

**Current state:** 119 files in limbo, waiting for manual import that never happens.

### Why Not a Cron Job

A cron job running `import_research_cache.py` daily would move the files but wouldn't fix the root problem: **NHI generation is decoupled from the normal collector framework.**

The real gap: how did NHI research get generated and where should it go?

### Deferred Options (for Opus review)

1. **Integrate NHI into normal collector framework** — generate directly to ResearchStore
2. **Refactor NHI collection to use ResearchStore directly** (preferred)
3. **Make cache permanent with automation** (band-aid, not recommended)
4. **Enforce single path: cache → DB → delete cache** (requires rework of how research flows)

### Next Steps

When tokens allow Opus-level thinking:
1. Read the NHI generation code end-to-end (`research/collectors/` + related)
2. Map where 119 files came from (automated generation? manual? hybrid?)
3. Design proper integration with ResearchStore
4. Implement without cron-job patches

### Related Code

- NHI files: `research/cache/{astrix,clutch,entro,vorlon,appomni,grip,obsidian,valence}/`
- Import script: `bin/import_research_cache.py`
- ResearchStore: `pipeline/research_store.py`
- Collectors: `research/collectors/`
- Stage 3: `pipeline/pipeline_stages/stage_3.py` (lines 91-187)

**Commit:** d2acef5 (Operation Triple Crown Phase II)
