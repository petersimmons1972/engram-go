---
name: feedback-stochastic-pipeline-reruns
description: Before fixing pipeline code for a failure, verify the failure is deterministic — many Clearwatch failures are LLM generation variance that resolve on re-run
type: feedback
Category: feedback
---

Not every pipeline failure is a bug. Some are LLM generation variance (stochastic). Before modifying pipeline code, verify the failure reproduces deterministically.

**Why:** In the 2026-03-30 session, 3 of 4 "failing" reports were actually stochastic:
- CrowdStrike v251: Gate 27 failure on 703-char paragraph (limit 700, just 3 chars over) — pure variance
- SentinelOne_v_PaloAltoNetworks v076: "Paragraph with only citations" in FinalFormatValidator — passed on re-run
- MicrosoftDefender_v_PaloAltoNetworks v099: B- grade on pricing framing — passed on re-run with different framing

The ONLY deterministic failure was MicrosoftE5_v_CrowdStrikeFalcon: missing pricing fields in dossier caused 12/13 charts suppressed. No amount of re-running would fix it — structural data gap.

**How to apply:**
1. First failure → re-run once before touching code
2. If it passes on re-run → stochastic, no fix needed, note in run log
3. If it fails the same way on re-run → deterministic, investigate and fix
4. Exception: if failure is clearly structural (missing data, field not in dossier, import error) → skip re-run, fix the root cause directly

**The tell for deterministic vs stochastic:**
- Stochastic: failure is 3 chars over limit, or "occasionally" phrases, or margin cases
- Deterministic: missing field in data contract, import error, explicit suppression flag, always 0 charts

**Corollary:** Pipeline exit code 0 ≠ success. Always read stage-level status in the run log, not just process exit code.
