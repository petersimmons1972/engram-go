---
name: Global To-Do List
description: Periodic tasks and checks to revisit across all projects
type: project
---

# Global To-Do List

Items to check periodically when requested. Add with date discovered and context.

## Clearwatch

- **Check linting rules** (discovered 2026-03-26)
  - Review report linting rules for quality gates
  - Context: General quality maintenance for Clearwatch reports
  - Status: Pending user request to review

- **X3: Stage 7 inter-reviewer variance** (discovered 2026-03-31, from Operation Synapse)
  - Status: ✅ COMPLETE — rotating reviewers are well-calibrated (mean spread 0.69)

- **C1: Gate effectiveness audit** (discovered 2026-03-31, from Operation Synapse)
  - Spreadsheet: last 20 report runs × 26 gates — fires / defects caught / bypass incidents
  - Data source now available: `python bin/validate-all-existing.py --json > docs/gate-baseline.json`
  - Gate replay harness on main — can produce corpus-wide pass/fail matrix in ~60s
  - Status: Pending (data source ready, analysis not done)

- **Gate replay harness** (shipped 2026-03-31)
  - `bin/validate-existing.py` — single report gate table
  - `bin/validate-all-existing.py` — corpus-wide (--latest-only, --json, --limit, --pair)
  - `tests/regression/test_gate_regression.py` — 6 GOLD baselines, ~7.5s
  - Status: ✅ SHIPPED to main (d87a0b5)

- **Must fix before ANY regen** (2026-03-31) ⚠️
  - #3818 — CONTENT-RULES vs stage_3.py contradiction → empty key-insight shells (ALL pairs)
  - #3821 — Buyer Profiles section empty — structural prompt gap (ALL pairs)
  - #3794 — CVE language overstates risk — needs domain-knowledge rule
  - #3836 — CVE-2024-5912 unverified in live S1_v_PA report — HIGH/defamatory risk
  - #3835 — S1 pricing $210 vs $160-180 dossier inconsistency
  - Status: Pending — do these BEFORE any regen run

## Engram

- **E1: Semantic dedup via cosine similarity** (discovered 2026-03-31, from Operation Synapse)
  - Add cosine similarity dedup at 0.92 threshold to `_dedup_chunks()` in consolidate()
  - Infrastructure already exists: `get_all_chunks_with_embeddings()` + `cosine_similarity`
  - Hash-only dedup is a ticking bomb as multi-agent usage grows
  - Status: Pending — ~1 day effort

- **E2: Evidence/authority weighting** (discovered 2026-03-31, from Operation Synapse)
  - Add `authority` field, weight user-corrected memories higher in composite score
  - Requires DB migration across SQLite + PostgreSQL — design migration first
  - Status: Design-first, 3-month horizon

- **E3: Truncation convention doc** (discovered 2026-03-31, from Operation Synapse)
  - Document at MCP boundary: callers responsible for truncation, not engram internals
  - 15-minute documentation change
  - Status: Pending

- **Engram golden test set** (discovered 2026-03-31, from Operation Synapse)
  - 5 deterministic query/expected-memory assertion pairs before any LLM-as-judge layer
  - Status: Pending — one afternoon

## Infrastructure

- Monitor cert-manager DNS-01 challenges (known issue with local CNAME records)
- Verify Cloudflare negative DNS cache purges (1800s TTL)
- Check K8s node readiness and PVC status

## Armies 2.0

- **PyPI publish — armies package** (discovered 2026-03-27) ⚠️ FOUNDER ONLY
  - Upload `armies` package to PyPI so `pip install armies` works for external users
  - Keys stored in standard credential locations (~/.pypirc or Infisical)
  - Build is ready: `dist/` has sdist + wheel for v0.1.0
  - Command: `TWINE_PASSWORD=<token> twine upload --username __token__ dist/*`
  - **DO NOT delegate to any agent. Founder executes personally.**
  - Status: Pending — skipped for now, do when ready to go fully public

- **GitHub documentation — narrative-first, richly illustrated** (discovered 2026-03-27)
  - The README and docs must be written to be *read*, not just referenced
  - Requirements: flowing narrative, examples, diagrams, illustrations, pictures, step-by-step walkthroughs with context
  - Tone: explain WHY and HOW things work, not just the bare mechanics
  - Anti-pattern to avoid: sparse GitHub READMEs that only list commands with no story
  - This applies to: README, PROGRESSION-SYSTEM, role taxonomy docs, profile schema docs, quickstart guide
  - Status: Pending — do this when writing Layer 6 docs and pre-release polish

## Armies

- **A1: Guard ablation testing** (discovered 2026-03-31, from Operation Synapse)
  - Test 3-5 explicit profile rules WITH/WITHOUT on adversarial scenarios
  - LLM judge classifies behavioral difference; rubric: >20% change in tool selection or output structure
  - Validates whether 8-18KB biographical profiles produce behavioral differentiation
  - Status: Pending — ~1 day effort

- **A2: Multi-tool output sync** (discovered 2026-03-31, from Operation Synapse)
  - Count Claude Code-specific constructs in one profile; if <20%, thin adapter per tool suffices
  - Status: File as issue, review in 6 months

- **X7: Clearwatch outcome tracking** (discovered 2026-03-31, from Operation Synapse)
  - Retrospective correlation query: do GOLD-passing reports produce fewer revision requests?
  - Start with existing data, no new instrumentation
  - Status: Pending — depends on revision history being queryable

## Engram

- **OWUI service discovery** (discovered 2026-03-28)
  - Engram should query OWUI's admin API on startup to discover the Ollama endpoint automatically
  - Only config Engram needs: OWUI URL + credential. No separate OLLAMA_URL.
  - Requires: investigate OWUI's admin API for Connections/Ollama endpoint exposure
  - Context: Discovered during repackaging discussion — OWUI already knows where Ollama is (e.g. http://192.168.0.98:11434), Engram shouldn't need to be told separately
  - Status: Medium-term — not blocking current work

## Medium-Term Projects

- **Extracting Nate's Wisdom** (discovered 2026-03-26)
  - Channel: https://www.youtube.com/@NateBJones
  - Pull YouTube transcripts from entire channel, extract wisdom/principles
  - Apply that wisdom to codebase + business practices — identify what to do differently
  - Stretch: connect to calendar + email and run the same analysis
  - Context: Idea from a conversation screenshot — "have Claude Code pull transcripts, summarize the whole channel, extract wisdom, apply to entire codebase"
  - Status: Pending — medium-term initiative

---

**How to use:** User periodically asks "give me the global to-do list" and this file is retrieved and summarized.
