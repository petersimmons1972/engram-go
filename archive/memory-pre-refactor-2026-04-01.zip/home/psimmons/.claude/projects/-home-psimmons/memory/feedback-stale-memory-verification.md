---
name: feedback-stale-memory-verification
description: Always verify session handoff claims against current repo/file state before acting — two handoff notes were wrong in one session
type: feedback
Category: feedback
---

Session handoff notes are point-in-time snapshots. They go stale. Never act on a handoff note without a quick verification step.

**Why:** In the 2026-03-30 session, two critical handoff notes were wrong:
1. "Engram repackaging blocked on OLLAMA_API_KEY" — key was already in `.env`, `feature/external-ollama` already merged. Would have wasted a debugging session.
2. "Quality campaign awaiting merge" — branch had already been merged to main weeks earlier. `git merge-base --is-ancestor` confirmed immediately.

Both errors would have caused unnecessary, expensive work if acted on blindly.

**How to apply:**
- Before acting on "still needs X" in a handoff: check the current state with one command
- "Branch needs merge" → `git merge-base --is-ancestor <branch> main`
- "Service blocked on config" → check the actual config file
- "Tests failing" → run the tests fresh, don't trust the handoff count
- Trust current state over memory. Memory records what WAS true; the file system records what IS true.
- If a handoff memory turns out to be wrong, update or delete it immediately — stale memories compound.
