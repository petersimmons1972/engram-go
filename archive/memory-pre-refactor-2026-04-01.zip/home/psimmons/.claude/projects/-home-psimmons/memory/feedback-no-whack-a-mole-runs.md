---
name: feedback-no-whack-a-mole-runs
description: When single-bug fix cycles aren't getting reports through after 2+ runs, STOP and do comprehensive root-cause analysis before running again
type: feedback
---

Do NOT keep pushing single-bug fixes through multi-hour report runs when reports still aren't completing.

**Why:** After 2 consecutive run cycles that fix one bug each but still fail to ship a report, the approach has failed. Each 2-hour run is expensive and reveals only the NEXT bug in sequence, not all bugs simultaneously.

**How to apply:**
1. After 2 fix-run cycles with no reports shipping, STOP running reports
2. Do comprehensive static failure analysis first: enumerate ALL failure classes across ALL pairs from existing logs
3. Fix the entire failure set in one pass before the next run
4. Smoke-test a SINGLE pair before committing to a full 6-report run
5. Only then run all 6

**The tell:** "We're hours into this and still not getting a report through the finish line."

**Alternative tools:**
- `python3` frequency analysis on run logs to rank failure classes by count
- Single-pair smoke test: `python bin/generate-report.py dossiers/X.json output/X --auto-version`
- Zero-context reviewer for fresh-eyes pattern analysis
