---
name: Clearwatch issue triage — 108 issues categorized 2026-03-29
description: Full categorization of all open Clearwatch issues into labeled buckets, with systemic patterns identified
type: project
---

108 open issues categorized and labeled on GitHub (2026-03-29):

| Bucket | Label | Count |
|--------|-------|-------|
| needs-report-run | `needs-report-run` | 38 (35%) |
| chart-geometry | `chart-quality` | 26 (24%) |
| pipeline-bug | `pipeline-bug` | 20 (19%) |
| research-data | `research` | 12 (11%) |
| epics | `epic` | 4 (4%) |
| security | `security` | 3 (3%) |
| design-debt | `design-debt` | 1 (1%) |

**Key insight**: 38 "needs-report-run" issues split into two types: (a) genuine re-run verification (code fix landed, needs regen) and (b) prompt-quality issues that will RECUR on every run. The prompt overhaul (PR #3643, merged) addresses 30 of the prompt-quality issues.

**Systemic patterns in pipeline-bug/chart-geometry**:
- WCAG contrast: 6 issues, same gray color family on navy background
- viewBox bottom collision: 4 issues, static heights don't flex
- Equal-score label collision: 2 issues, no collision resolution
- Stage 5.x normalizer gaps: 3 issues, piecemeal fixups
- Generic chart titles: 3 issues, no vendor-name check

**Why:** Issue triage needed before running quality campaigns or report regeneration — determines which fixes are code changes vs prompt changes vs just re-runs.

**How to apply:** After any report batch run, re-triage against these labels. Pattern-level fixes auto-resolve multiple issues — check before filing new ones.
