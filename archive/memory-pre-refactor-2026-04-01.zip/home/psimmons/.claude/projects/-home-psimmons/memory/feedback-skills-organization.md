---
name: feedback-skills-organization
description: Where custom skills live — global vs project-scoped, never mixed with upstream cache
type: feedback
---

Three distinct locations for skills — never mix them:

| Location | Purpose |
|----------|---------|
| `~/.claude/plugins/cache/` | Upstream plugin skills — NEVER edit |
| `~/.claude/skills/` | Global custom skills (cross-project) |
| `{project}/.claude/skills/` | Project-scoped skills (only available in that project) |

**Why:** Session 2026-03-31 — 8 Clearwatch-specific skills were sitting in `~/.claude/skills/` (global), making them available everywhere unnecessarily. Moved to `~/projects/clearwatch/.claude/skills/`.

**How to apply:** When writing a new skill, ask: is this useful in every project, or only this one? Project-specific → project `.claude/skills/`. Otherwise → `~/.claude/skills/`.

**Clearwatch skills (in project):** adversarial-source-check, cf, clearwatch-preflight, clearwatch-quality-campaign, integrate-feedback, quality-auditor, validate-charts, visual-output-standards

**Global skills:** analyzing-companies, brutal-evaluation, find-skills, linkedin-content, marketing-psychology, memory-cleanup, playwright-testing, status, ui-ux-pro-max
