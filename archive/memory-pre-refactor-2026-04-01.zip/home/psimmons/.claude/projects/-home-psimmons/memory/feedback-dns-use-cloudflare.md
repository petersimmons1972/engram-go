---
name: feedback-dns-use-cloudflare
description: DNS records for petersimmons.com are managed via Cloudflare API — do not ask for passwords or SSH sudo
type: feedback
---

Split DNS is in use. Internal records go to Ubiquiti (NOT Cloudflare). Cloudflare is only for public-facing records.

**Why:** The network uses split DNS. Publishing internal service records to Cloudflare exposes internal topology externally and breaks the split-horizon design. Only records that should resolve from the public internet go in Cloudflare.

**How to apply:**
- Internal service (e.g. research-postgres, Traefik CNAMEs, cluster services) → Ubiquiti local DNS
- Public-facing service (e.g. reports.petersimmons.com, resume, tor) → Cloudflare
- Cloudflare zone ID: `460653bc26ff94fdc0910a13defa4afb`, token in ~/.claude/.cloudflare-credentials
- Ubiquiti credentials: UNKNOWN — need to locate. Do not ask user for passwords; find them.
- Do NOT default to Cloudflare for *.petersimmons.com records without confirming public intent.
