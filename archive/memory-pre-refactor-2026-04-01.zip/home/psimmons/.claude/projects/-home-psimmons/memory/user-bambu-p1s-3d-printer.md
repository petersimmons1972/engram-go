---
name: user-bambu-p1s-3d-printer
description: User owns a Bambu Lab P1S 3D printer (serial 3DP-01P-519), network access, AMS with PLA, vision limitations, troubleshooting history
type: user
---

User owns a Bambu Lab P1S 3D printer (device ID: 3DP-01P-519).
- Uses an AMS (Automatic Material System) with multiple PLA spools
- Has limited close-up vision — small parts like thermistors and FPC cables are difficult to work with
- Comfortable disassembling the printer but benefits from specific tactile cues ("what should I feel") over visual inspection instructions
- Phone camera as magnifier is a useful tip for this user

**Network access:**
- IP: 192.168.0.51
- FTPS on port 990, user: bblp, access code: 682c6121
- Logs at /logger/ directory, corelogger at /corelogger/
- Logs are AES encrypted — only Bambu support can decrypt

**Troubleshooting history (2026-03-30):**
- Filament cutter handle error → caused by FPC ribbon cable seated 1mm off
- Hotend cooling fan speed abnormal → fan spinning intermittently, connector/board issue
- Nozzle temp open circuit → resolved by reseating thermistor deeper
- Part cooling fan speed abnormal → latest error, same signal path as others
- Root cause: likely FPC cable marginal connection — all 4 errors share same ribbon cable path
- Problems started 2026-03-29 on firmware v01.09.01.00 (before update to v01.10.00.00)
- Logs downloaded to ~/bambu-p1s-logs/ for Bambu support ticket
- Awaiting warranty replacement of FPC cable + Extruder Connection Board (FAE002)
