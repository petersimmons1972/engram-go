---
name: Google News RSS is the primary event collection source
description: For conference/event-based research collection, Google News RSS search queries vastly outperform traditional RSS feeds
type: feedback
---

Google News RSS (`https://news.google.com/rss/search?q=...`) is a massive force multiplier for event-based collection. 4 Google News queries yielded 293 items in a single run, vs 7 items from 14 traditional RSS feeds.

**Why:** Traditional RSS feeds only show the most recent 10-50 items and rotate quickly. Conference content from 4-6 days ago is already gone. Google News indexes everything and returns 100 items per query. It captures trade press, analyst coverage, channel media, and vendor announcements that individual RSS feeds miss.

**How to apply:** For any time-sensitive research collection (conferences, incidents, product launches), always include Google News RSS queries as the primary source. Traditional vendor/trade RSS feeds are supplementary. Use quoted phrases for precision (`%22RSAC+2026%22`) and broader keyword queries for coverage.
