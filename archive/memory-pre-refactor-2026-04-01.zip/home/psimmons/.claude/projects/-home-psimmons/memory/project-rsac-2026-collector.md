---
name: RSAC 2026 collector architecture and status
description: K8s CronJob collector for RSA Conference data — architecture, data sources, known issues, and 2026-03-30 fix details
type: project
---

**K8s CronJobs** in namespace `clearwatch-research`:
- `collector-rsac-2026` — Wednesdays 7am UTC, runs `rsac_2026.py`
- `collector-rsac-tagger` — Wednesdays 7:30am UTC, attributes items to vendors

**Data sources** (after 2026-03-30 fix):
- Google News RSS (4 queries — primary source, ~293 items per run)
- 28 RSS feeds (security trade press + vendor blogs)
- HackerNews Algolia API (7 queries)
- Reddit public JSON API (6 subreddits x 4 queries — currently 403 blocked, no auth token)
- Vendor blog scraper (18 blog listing pages, checks URLs + fetches article content)

**Storage**: PostgreSQL `clearwatch_research` DB, table `collected_items`, user `research`. 273 items as of 2026-03-30.

**Known issues**:
- Reddit returns 403 on most subreddits — needs OAuth token, currently ignored
- Vendor blog scraper still low-yield (0-1 items) — listing pages don't surface event names well
- Broken RSS feeds removed: threatpost (timeout), sophos (timeout), fortinet/trendmicro/techcommunity (404)
- scmagazine.com feed returns malformed XML

**Why:** RSAC collector ran during March 19-25 but the March 25 run (during RSAC) failed. Pre-conference runs found near-zero items. Post-fix runs with Google News RSS captured 223 new items covering all 4 RSAC days.

**How to apply:** For future conferences (Black Hat, DEF CON, Gartner SRM), clone rsac_2026.py pattern with event-specific Google News queries. Google News RSS is the primary collection channel.
