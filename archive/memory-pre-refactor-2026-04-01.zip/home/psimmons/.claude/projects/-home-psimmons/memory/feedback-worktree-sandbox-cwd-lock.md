---
name: feedback-worktree-sandbox-cwd-lock
description: When a session's worktree is deleted, the sandbox locks to the dead path — spawn a fresh agent instead of fighting it
type: feedback
---

Once a git worktree directory is deleted mid-session, every subsequent Bash tool call fails with "Path ... does not exist" regardless of absolute paths or -C flags. The sandbox checks the cwd at the OS level before executing.

**Why:** Session 2026-03-31 — the bug-campaign-14-issues worktree was deleted by the merge agent while the parent session was still running in it. All remaining Bash calls failed.

**How to apply:**
- For any git or file operations after this point, spawn a subagent (grace-hopper or general) — they start with a clean cwd
- Use Read/Grep tools for file inspection; they are not affected by the cwd lock
- Don't waste attempts on `dangerouslyDisableSandbox` — it doesn't fix cwd-not-found errors
