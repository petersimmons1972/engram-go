---
name: feedback-issue-lifecycle-by-version
description: needs-report-run issues are version-specific — close old version's issues when new version runs, even if the specific bug wasn't explicitly fixed
type: feedback
Category: feedback
---

GitHub issues labeled `needs-report-run` are tied to a specific report version. When a new version runs successfully (GOLD status, A- or better), close all old `needs-report-run` issues for that pair — regardless of whether each specific problem was explicitly addressed.

**Why:** A new version may have fixed the issue through improved LLM generation, different dossier data, or updated pipeline code. Keeping old-version issues open creates false "debt" — the issue referenced v073 behavior, but we're now on v089. The new version's Stage 7 auto-files fresh GitHub issues for any new problems found.

**How to apply:**
- After a successful report run (GOLD status): query `gh issue list --label needs-report-run` for that vendor pair
- Close all issues for versions older than the current run with comment: "Superseded by v{NNN} (GOLD status, {date})"
- New Stage 7 failures auto-create fresh issues — trust the pipeline's issue creation
- Do NOT carry forward old version's defect catalog into new version tracking
- Exception: issues labeled `research` or `data-gap` may persist across versions if the underlying data hasn't changed

**Cross-reference:** After closing old issues, check if any open issues can now be closed in bulk by cross-referencing commit messages. 14 issues were bulk-closeable in the 2026-03-30 session once recent commits were read.
