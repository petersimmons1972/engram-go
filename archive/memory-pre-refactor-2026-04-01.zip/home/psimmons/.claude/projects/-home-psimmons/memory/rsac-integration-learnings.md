---
name: RSAC 2026 Integration — Key Learnings
description: Technical patterns, process insights, and architecture decisions from database-backed enrichment integration
type: feedback
---

## Architecture Decisions

### Database-Backed Enrichment Over File Storage
**Decision:** Query `collected_items` table at dossier generation time rather than pre-materializing enriched data.

**Why:**
- Single source of truth (avoids stale file copies)
- File management complexity eliminated
- Supports dynamic filtering by vendor/claim-type
- Data quality fixes apply retroactively (no re-materializing)

**Application:** Any enrichment pipeline using external reference data.

---

### Append-Only Enrichment Pattern
**Decision:** Add RSAC claims to specific manifest subsections without modifying existing vendor data.

**Why:**
- Preserves existing manifest structure and integrity
- Safe to run multiple times (idempotent)
- New enrichment doesn't break downstream reports
- Easy to disable enrichment by skipping enrichment stage

**Pattern:** For each claim type, append to `manifest[section][vendor][rsac_subsection]` list:
```python
# Before: manifest may have existing sentiment data
manifest["sentiment"]["crowdstrike"] = {
    "g2_rating": 4.5,
    "analyst_notes": [...]
}

# After enrichment: RSAC data appended to new key
manifest["sentiment"]["crowdstrike"]["rsac_sentiment"] = [
    {"id": "...", "title": "...", "url": "..."}
]
```

---

### Per-Vendor Configuration with JSON + Fallback Pattern
**Decision:** Externalize vendor thresholds to config file with default fallback.

**Why:**
- Operators can adjust thresholds without code deployment
- New vendors automatically get defaults
- Easy to override for specific vendors (Fortinet min:3, SentinelOne max:120)
- File lives in repo with code (not K8s ConfigMap bloat)

**Pattern:**
```json
{
  "default": { "min": 5, "max": 100 },
  "vendors": {
    "fortinet": { "min": 3 }
  }
}
```

Validator checks: `_load_config()` → merge with defaults → use per-vendor threshold.

**Application:** Any multi-tenant validation where thresholds vary by customer/vendor.

---

### Routing Table for Extensibility
**Decision:** Map claim types to manifest sections via constant routing table instead of if/elif chains.

**Replaces:** 66-line if/elif chain with 10-line DRY constant:
```python
CLAIM_ROUTING = {
    "pricing": "pricing.rsac_updates",
    "sentiment": "sentiment.rsac_sentiment",
    "detection": "detection.rsac_benchmarks",
    # ... add new types without touching code logic
}
```

**Why:**
- New claim types require only adding one config line
- No code logic changes = fewer bugs
- Testable: loop through routing table, verify each path exists

**Application:** Any system mapping source types to destination structures.

---

## Process Patterns

### Two-Stage Code Review (Spec → Quality)
**Order matters:**
1. **Spec compliance first** — Does code implement the spec? Missing features? Extra features?
2. **Code quality second** — Is it well-written? Constants extracted? Tests adequate?

**Why:**
- Spec compliance catches what you DIDN'T do (functional gaps)
- Code quality catches how you did it (implementation issues)
- Reversing the order wastes time: fix quality issues on code that doesn't match spec

**Enforcement:** Spec reviewer must approve before code reviewer sees it.

---

### Dry-Run Mode for Destructive Operations
**Pattern:** All modify operations support `--dry-run` (default) and `--apply` modes.

**Why:**
- Operator sees exact changes before running
- No surprises in production
- Reversible: if dry-run shows something wrong, abort before modifying

**Implementation:** Single boolean flag, conditional execute in each method:
```python
if self.dry_run:
    print(f"Would update {len(items)} items")
else:
    cur.execute("UPDATE ..."); self.conn.commit()
```

**Application:** Any maintenance script (data cleanup, migrations, repairs).

---

### Manual Review Tracking via Metadata
**Decision:** Flag problematic items in `raw_json` with `fix_status` field for human review.

**Why:**
- Audit trail: what was flagged and why
- Operator knows what still needs manual intervention
- Supports multi-phase workflows: cleanup script flags, operator reviews, operator clears flag

**Values:** `missing_url`, `missing_title`, `invalid_url`, `duplicate_title`, etc.

**Application:** Any system where automation + human review happen in sequence.

---

### Multi-Phase Processes with Clear Success Criteria
**Pattern:** Diagnosis → Repair → Validation (4-5 day cycle)

**Why:**
- Phase 1 (diagnosis) identifies scope without touching data
- Phase 2 (repair) modifies with dry-run preview
- Phase 3 (validation) confirms quality target met
- Rollback plan if Phase 3 fails

**Success metrics:** Quality score ≥95%, zero NULL required fields, all vendors assigned, zero invalid URLs, P9 gate passes.

---

## Configuration & Operational Patterns

### Non-Blocking Validation for Optional Features
**Decision:** RSAC enrichment validation returns WARN (not FAIL) if vendor coverage gaps detected.

**Why:**
- Enrichment is optional (reports work without it)
- Coverage gaps shouldn't prevent dossier generation
- Operator sees warning but pipeline continues
- Downstream teams can decide whether to use enrichment

**Implementation:** ValidationResult with `level="WARN"` and descriptive message.

---

### Exception Safety in Critical Paths
**Decision:** P9 gate wraps enrichment in try-catch to prevent malformed manifest from crashing Stage 0.5.

**Why:**
- Enrichment is bolted-on (shouldn't break existing pipeline)
- Database connectivity isn't guaranteed
- Graceful degradation: if enrichment fails, dossier generates without it

---

## Testing Patterns

### Fixture-Based Config Testing
**Pattern:** Use `temp_config_file` fixture for isolated config tests:
```python
def test_validator_loads_config(temp_config_file):
    validator = RSACEnrichmentValidator(
        use_default_config=True,
        config_path=str(temp_config_file)
    )
    # test passes/fails based on config
```

**Why:**
- Tests don't interfere with each other
- Backward compatibility preserved (tests run with and without config)
- No need to mock filesystem

---

## Lessons for Future Work

1. **Database queries should be explicit and auditable.** Diagnostic scripts should show exactly which rows they're examining (SELECT with WHERE visible in output).

2. **Cleanup scripts need explicit confirmation steps.** Dry-run prevents surprises, but operator should still review flagged items (vendor mapping, title extraction) before auto-fix runs.

3. **Config files beat code for operator-facing parameters.** Thresholds, vendor lists, and routing rules should live in YAML/JSON, not constants.

4. **Routing tables scale better than if/elif chains.** Both are fine at 3 cases. At 10+ cases, routing table is cleaner.

5. **Two-stage review catches bugs that individual reviews miss.** Spec compliance reviewer found "config loading auto-activation" bug that code quality reviewer wouldn't catch (it's technically well-written, just wrong feature).

6. **Metadata fields in JSON are cheaper than schema changes.** Flagging items with `fix_status` avoids adding columns to the table (which requires migration).

