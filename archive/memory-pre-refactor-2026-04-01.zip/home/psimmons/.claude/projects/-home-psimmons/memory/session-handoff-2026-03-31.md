---
name: session-handoff-2026-03-31
description: Session exit handoff — gate replay harness shipped, regen cycle anti-pattern diagnosed, must-fix list before any regen
type: project
Category: project
---

# Session Handoff — 2026-03-31 (final)

## What Was Done This Session

### Bug Campaign 14 — FULLY CLOSED
All 14 original issues fixed, committed, merged to main. Additional fixes:
- `ec4431e` Stage 5.8 no longer blocks on empty key-insight divs (#3818)
- `f84fb8f` Decision sankey "Tied" → "Your Stack Determines the Winner"
- `d65a82a` Tier classifier + field normalizer fixes (#3314)
- `aa2c740` Collector 7-day error expiry (#2924)
- `d014f92` Security: #3105 all raw subprocess claude eliminated
- `a48a081` Fix #3818 root cause: CONTENT-RULES.md raw HTML requirement removed, stage_3.py scope clarified
- `0a936be` Removed debug HTML dump left in orchestrator.py

### Gate Replay Harness — SHIPPED TO MAIN
11 commits, `d87a0b5` final merge. Replays Stage 6 gates in ~60s instead of 60-min full pipeline.

**New files:**
- `bin/gate_replay_lib.py` — artifact loader, DEGRADED_GATES = {"10","15","16","18","28","31"}
- `bin/validate-existing.py` — single-report gate table (PASS/FAIL/DEGRADED/WARN)
- `bin/validate-all-existing.py` — corpus-wide scan (--latest-only, --json, --limit, --pair flags)
- `tests/regression/test_gate_regression.py` — 6 GOLD pairs parametrized, ~7.5s

**Workflow going forward:**
1. Fix gate/rule/dossier issue
2. `python bin/validate-existing.py output/<Pair>/<ver>` — confirm gate passes
3. `pytest tests/regression/` — confirm no regressions
4. Only THEN: `bash bin/run-tier1-reports.sh`

**Corpus scan results (--latest-only):**
- 5/7 latest reports: FAIL only on degraded gates (no real content failures)
- S1_v_MsDefender v096: Gate 27 wall-of-text 759 chars (already on regen list)
- Identity_Security_Market_Map v009: 12 non-degraded failures (different template, skip)

### Stage-7 Feedback Triage (~41 issues from v116/v082)
- ~20 closed via prompt rules added to CONTENT-RULES.md
- 4 DATA_GAP researched → dossiers corrected (E5 $24K→$49,995, 8x ratio sensitivity, $100→$150-180 MDR)
- CVE-2024-5909 and CVE-2024-8690 verified in `research/cache/cve-verification-2026-03-31.md`

### Reports Shipped
| Pair | Version | Grade | latest/ |
|------|---------|-------|---------|
| PaloAltoNetworks_v_CrowdStrike | v120 | A- ✅ | updated |
| SentinelOne_v_PaloAltoNetworks | v083 | A- ✅ | updated |

---

## State at Handoff

### Test Suite
- **6921 passed, 165 skipped, 0 failures** — fully green
- Gate replay harness: 6 regression tests + 9 unit tests, all green

### GOLD Baselines
| Pair | GOLD Version |
|------|-------------|
| CrowdStrike_v_SentinelOne | 254 |
| PaloAltoNetworks_v_CrowdStrike | 120 |
| SentinelOne_v_MicrosoftDefender | 092 (v093-096 Gate 27 failures) |
| MicrosoftDefender_v_PaloAltoNetworks | 104 |
| SentinelOne_v_PaloAltoNetworks | 083 |
| MicrosoftE5_v_CrowdStrikeFalcon | 088 |

---

## Must Fix BEFORE Any Regen (Structural — Will Repeat Every Run)

These issues produce the same Stage 7 feedback on every regeneration. Fix first or regen is wasted compute.

| Issue | Problem | Impact |
|-------|---------|--------|
| **#3818** | CONTENT-RULES vs stage_3.py callout contradiction → empty key-insight shells | ALL pairs |
| **#3821** | Buyer Profiles section empty — structural prompt gap | ALL pairs |
| **#3794** | CVE language overstates risk — needs domain-knowledge rule | ALL pairs with CVE |
| **#3836** ⚠️ HIGH | CVE-2024-5912 in S1_v_PA v083 — unverified CVE in live report, defamatory risk | S1_v_PA only |
| **#3835** | S1 pricing $210 vs $160-180 — dossier inconsistency | S1_v_PA only |

---

## Already Fixed — Just Need Regen

| Pair | Fixed Items |
|------|-------------|
| MicrosoftE5_v_CrowdStrikeFalcon | $24K→$49,995 dossier correction |
| MicrosoftDefender_v_PaloAltoNetworks | 8x ratio sensitivity dossier correction |
| SentinelOne_v_MicrosoftDefender | $100→$150-180 MDR dossier correction |

---

## Pending Regen Queue (User Has NOT Authorized)

| Pair | Current | Issues |
|------|---------|--------|
| CrowdStrike_v_SentinelOne | v257 | #3770, #3771, #3772, #3775 |
| SentinelOne_v_MicrosoftDefender | v096 | #3786, #3787, #3788, #3792 |
| MicrosoftDefender_v_PaloAltoNetworks | v104 | #3793, #3794, #3796 |
| MicrosoftE5_v_CrowdStrikeFalcon | v088 | #3754, #3755, #3756, #3757 |

### v120 Prose Issues (next PA_v_CS run)
- #3819 MDR no-equivalent not fully explored
- #3820 $79,500 list-price assumption
- #3821 Buyer Profiles section empty
- #3822 Chart rendering problems
- #3823 Exec summary verdict buried
- #3824 Paragraph length 685 chars

---

## How to Start Next Session

1. `cd /home/psimmons/projects/clearwatch`
2. Fix must-fix issues first (especially #3818 + #3821 — affect all pairs)
3. Verify CVE-2024-5912 (#3836): `research/cache/cve-verification-2026-03-31.md` then NVD
4. Run `python bin/validate-existing.py output/<Pair>/<ver>` after each fix
5. Run `pytest tests/regression/` before any regen
6. Only then: `bash bin/run-tier1-reports.sh`
